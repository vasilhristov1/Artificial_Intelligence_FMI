package hw5;

public class Main {
    public static void main(String[] args) {
        NaiveBayesClassifier NBC = new NaiveBayesClassifier();

        NBC.test();
    }
}
