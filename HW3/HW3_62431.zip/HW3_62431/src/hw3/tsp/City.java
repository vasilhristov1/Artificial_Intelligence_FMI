package hw3.tsp;

import java.util.Objects;

public class City {
    private int x;
    private int y;

    public City(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() {
        return this.x;
    }

    public int getY() {
        return this.y;
    }

    public double calculateDistance(City city) {
        int xDistance = Math.abs(this.getX() - city.getX());
        int yDistance = Math.abs(this.getY() - city.getY());

        return Math.sqrt((xDistance * xDistance) + (yDistance * yDistance));
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        final City city = (City) obj;
        return x == city.x && y == city.y;
    }

    public int hashCode() {
        return Objects.hash(x, y);
    }
}
